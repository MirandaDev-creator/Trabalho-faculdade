# Movimento Sem Fome (MSF) — Equipe 404

Site institucional (HTML5 + CSS3) com 10 páginas sobre redução do desperdício de alimentos e impacto social, com foco em acessibilidade.

**Integrantes:** Guilherme Lima de Souza, Guilherme Miranda Sena, Guilherme Vilela Frassão, Nathan de Oliveira Tavares, João Vitor Gonçalves de Oliveira, Kaue Dogani Moreira.

**Divisão de funções:** a preencher pela equipe.
